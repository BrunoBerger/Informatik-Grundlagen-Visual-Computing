#ifndef cmdArgs_h
#define cmdArgs_h

#include <vector>
std::vector<int> getIntArgs(int argc, char* argv[]);

#endif
