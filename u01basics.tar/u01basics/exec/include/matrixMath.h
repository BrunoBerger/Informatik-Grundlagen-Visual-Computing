#ifndef matrix
#define matrix

#include <armadillo>
arma::mat getRandomMat(int, int);

#endif
